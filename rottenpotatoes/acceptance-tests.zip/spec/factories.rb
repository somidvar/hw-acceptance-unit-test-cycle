FactoryBot.define do
  # Register movie factory
  factory :movie do
  end
end